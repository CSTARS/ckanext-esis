JSZip for Twitter Bower
=======================

This is a repository used to add jszip to the bower components repository.

jszip is written by Stuart Knightley and is dual-licensed. The details are in
LICENSE.markdown
