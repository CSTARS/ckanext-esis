var strs = {}; // shared strings
var _ssfopts = {}; // spreadsheet formatting options

