var styles = {}; // shared styles

